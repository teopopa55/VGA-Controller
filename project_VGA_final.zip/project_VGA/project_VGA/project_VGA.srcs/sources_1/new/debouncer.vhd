
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;


entity debouncer is
    Port ( BTN : in STD_LOGIC;
           CLK_DB : in STD_LOGIC;
           BTN_DB : out STD_LOGIC);
end debouncer;

architecture arch_debouncer of debouncer is
    signal Q : std_logic;
begin
      process(CLK_DB)
      begin
          if rising_edge(CLK_DB) then
               Q <= BTN;
           end if;
      end process;
      BTN_DB <= Q;
end arch_debouncer;
