library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;


entity VGA_controller is
    Port ( CLR_SEL : in STD_LOGIC_VECTOR (2 downto 0);
           SHP_SEL : in STD_LOGIC_VECTOR (1 downto 0);
           CLK : in STD_LOGIC;
           RST : in STD_LOGIC;
           RED : out STD_LOGIC_VECTOR (3 downto 0);
           GREEN : out STD_LOGIC_VECTOR (3 downto 0);
           BLUE : out STD_LOGIC_VECTOR (3 downto 0);
           HS : out STD_LOGIC;
           VS : out STD_LOGIC;
           BTN_UP : in STD_LOGIC;
           BTN_DOWN : in STD_LOGIC;
           BTN_LEFT : in STD_LOGIC;
           BTN_RIGHT : in STD_LOGIC);
end VGA_controller;

architecture Behavioral of VGA_controller is
  -- Clocks
 signal pix_clock    : std_logic;   --to update the pixel counters and control when to draw each pixel
 --we will divide 100MHz to 25MHz(Nexys A7100t)-main clock
 --because the VGA 640�480 standard requires a pixel clock of aprox 25 MHz
 signal clk_db       : std_logic;  --the clock of the debouncer
    
 signal count : integer range 0 to 3 := 0; --for the clock divider
 
-- Buttons
 signal btn_up_db    : std_logic;
 signal btn_down_db  : std_logic;
 signal btn_left_db  : std_logic;
 signal btn_right_db : std_logic;

-- Tracking horizontal and vertical points
 signal h_cnt        : unsigned(9 downto 0);  --0-799
 signal v_cnt        : unsigned(9 downto 0);  --0-524
 
 -- Coords to start drawing from center of screen
  signal x            : integer := 281;
  signal x_offset     : integer := 361;  -- right boundary
  signal y            : integer := 201;
  signal y_offset     : integer := 281;  -- bottom boundary
  
  -- Coords for center of circle
  signal h_center     : integer := (x + x_offset) / 2;
  signal v_center     : integer := (y + y_offset) / 2;
  signal radius       : integer := (x_offset - x) / 2;
  
  component debouncer is
        Port ( 
            BTN    : in std_logic;
            CLK_DB : in std_logic;
            BTN_DB  : out std_logic
         );
  end component;
 
begin
 
clk_div_25: process(CLK, RST) --we devide 100MHz into 25MHz
begin
    if RST = '1' then   --we start from the beginning, state 0
        pix_clock <= '0';
        count <= 0;  
    elsif rising_edge(CLK) then 
        if count = 1 then  --after 4 clock edges (each full period both high and low of the 25 MHz clock takes 4 rising edges of the 100 MHz clock)
            pix_clock <= not pix_clock;
            count <= 0;
        else
            count <= count + 1;
        end if;
    end if;
end process;
     
-- Frequency divider for moving shape
process(CLK, RST)
    variable count: std_logic_vector (18 downto 0) := (others => '0');
begin
    if rising_edge(CLK) then
       if RST = '0'then
           count := count + 1;
       else
           count := (others => '0');
       end if;
           clk_db <= count(18);
    end if;
end process;

-- Debouncing buttons
    Up:     debouncer port map(BTN_UP, clk_db, btn_up_db);
    Down:   debouncer port map(BTN_DOWN, clk_db, btn_down_db);
    Left:   debouncer port map(BTN_LEFT, clk_db, btn_left_db);
    Right:  debouncer port map(BTN_RIGHT, clk_db, btn_right_db);
    
-- Drawable size on screen + porches (640x480 resolution)
  HS <= '0' when h_cnt >= 656 and h_cnt < 752 else '1';  
  VS <= '1' when v_cnt = 512 or v_cnt = 513 else '0';
  
shape_draw: process(pix_clock, RST, CLR_SEL)
    -- Variables used to help draw shape
    variable h_cnt_int : integer;
    variable v_cnt_int : integer;
    variable h_dist : integer;
    variable v_dist : integer;
    variable dist_squared : integer;
begin
    if (RST = '1') then
        h_cnt <= to_unsigned(0, h_cnt'length);  --restarts the counters from 0 (accessing the length attribute of the h_cnt siganl)
        v_cnt <= to_unsigned(0, v_cnt'length);  --converts the integer 0 into an unsigned 10-bit value: 0000000000
    elsif rising_edge(pix_clock) then
        h_cnt_int := to_integer(h_cnt);  --converts the current horizontal and vertical pixel counters from unsigned to integers, so they can be used later on
        v_cnt_int := to_integer(v_cnt);

        -- Default background color
        RED <= "0000";  --default color of every pixel is set to black
        GREEN  <= "0000";  
        BLUE <= "0000";
    
    if SHP_SEL = "00" then
            -- Square
            if (h_cnt_int >= x and h_cnt_int <= x_offset and v_cnt_int >= y and v_cnt_int <= y_offset) then
                if CLR_SEL(0) = '1' then
                    RED <= "1111";
                end if;
                if CLR_SEL(1) = '1' then
                    GREEN <= "1111";
                end if;
                if CLR_SEL(2) = '1' then
                    BLUE <= "1111";
                end if;
            end if;
            
    elsif SHP_SEL = "01" then
            --Triangle
             if (h_cnt_int >= x and h_cnt_int <= x_offset and v_cnt_int >= y and v_cnt_int <= y_offset) then
                if(v_cnt_int >= -1 * h_cnt_int + (x_offset + y)) then
                     if CLR_SEL(0) = '1' then
                           RED <= "1111";
                     end if;
                     if CLR_SEL(1) = '1' then
                           GREEN <= "1111";
                     end if;
                     if CLR_SEL(2) = '1' then
                           BLUE <= "1111";
                     end if;
                 end if;
             end if;
             
     elsif SHP_SEL = "10" then
             -- X lines       
            if (h_cnt_int >= x and h_cnt_int <= x_offset and v_cnt_int >= y and v_cnt_int <= y_offset) then
                if (h_cnt_int - x) = (v_cnt_int - y) or v_cnt_int = y + (x_offset - h_cnt_int) or 
                   (h_cnt_int - x) - 1 = (v_cnt_int - y) or v_cnt_int = y + (x_offset - h_cnt_int) - 1 or
                   (h_cnt_int - x) - 2 = (v_cnt_int - y) or v_cnt_int = y + (x_offset - h_cnt_int) - 2 or
                   (h_cnt_int - x) - 3 = (v_cnt_int - y) or v_cnt_int = y + (x_offset - h_cnt_int) - 3 or
                   (h_cnt_int - x) - 4 = (v_cnt_int - y) or v_cnt_int = y + (x_offset - h_cnt_int) - 4 or
                   (h_cnt_int - x) - 5 = (v_cnt_int - y) or v_cnt_int = y + (x_offset - h_cnt_int) - 5 or
                   (h_cnt_int - x) + 1 = (v_cnt_int - y) or v_cnt_int = y + (x_offset - h_cnt_int) + 1 or
                   (h_cnt_int - x) + 2 = (v_cnt_int - y) or v_cnt_int = y + (x_offset - h_cnt_int) + 2 or
                   (h_cnt_int - x) + 3 = (v_cnt_int - y) or v_cnt_int = y + (x_offset - h_cnt_int) + 3 or
                   (h_cnt_int - x) + 4 = (v_cnt_int - y) or v_cnt_int = y + (x_offset - h_cnt_int) + 4 or
                   (h_cnt_int - x) + 5 = (v_cnt_int - y) or v_cnt_int = y + (x_offset - h_cnt_int) + 5 then
                        if CLR_SEL(0) = '1' then
                            RED <= "1111";
                        end if;
                        if CLR_SEL(1) = '1' then
                            GREEN <= "1111";
                        end if;
                        if CLR_SEL(2) = '1' then
                            BLUE <= "1111";
                        end if;
                  end if;
              end if;
         
       elsif SHP_SEL = "11" then
            -- Circle
            if (h_cnt_int >= x and h_cnt_int <= x_offset and v_cnt_int >= y and v_cnt_int <= y_offset) then
                h_dist := h_cnt_int - h_center;
                v_dist := v_cnt_int - v_center;
                dist_squared := h_dist * h_dist + v_dist * v_dist;
                if dist_squared <= radius * radius then
                    if CLR_SEL(0) = '1' then
                        RED <= "1111";
                    end if;
                    if CLR_SEL(1) = '1' then
                        GREEN <= "1111";
                    end if;
                    if CLR_SEL(2) = '1' then
                        BLUE <= "1111";
                    end if;
                end if;
            end if;
        end if;
        
  -- Increment counters (move to the next pixel)
        if (h_cnt < 800) then
            h_cnt <= h_cnt + 1;
        else 
            h_cnt <= to_unsigned(0, h_cnt'length);
            if (v_cnt < 524) then 
                v_cnt <= v_cnt + 1;
            else 
                v_cnt <= to_unsigned(0, v_cnt'length);
            end if;
        end if;
    end if;
end process;

move_shape: process(clk_db, RST)
begin
    -- Moves shape back in center on reset
    if RST = '1' then
        x <= 281;
        x_offset <= 361;
        y <= 161;
        y_offset <= 241;
    elsif rising_edge(clk_db) then
        if btn_up_db = '1' and y > 2 then
            y <= y - 1;
            y_offset <= y_offset - 1;
        end if; -- Moves up
        
        if btn_down_db = '1' and y_offset < 405 then
            y <= y + 1;
            y_offset <= y_offset + 1;
        end if; -- Moves down
        
        if btn_right_db = '1' and x_offset < 645 then
            x <= x + 1;
            x_offset <= x_offset + 1;
        end if; -- Moves right
        
        if btn_left_db = '1' and x > 2 then
            x <= x - 1;
            x_offset <= x_offset - 1;
        end if; -- Moves left
    end if;
end process;

end Behavioral;